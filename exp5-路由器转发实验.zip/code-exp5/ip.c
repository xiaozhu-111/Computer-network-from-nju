#include "ip.h"
#include "icmp.h"
#include "arpcache.h"
#include "rtable.h"
#include "arp.h"
#include "log.h"
#include <stdlib.h>
#include <assert.h>

// If the packet is ICMP echo request and the destination IP address is equal to the IP address of the iface, send ICMP echo reply.
// Otherwise, forward the packet.
// Tips:
// You can use struct iphdr *ip = packet_to_ip_hdr(packet); in ip.h to get the ip header in a packet.
// You can use struct icmphdr *icmp = (struct icmphdr *)IP_DATA(ip); in ip.h to get the icmp header in a packet.
// 如果是ICMP EchoRequest数据包，并且目标IP地址等于收到它的接口的 IP 地址，则发送ICMP EchoReply数据包
// 否则，转发数据包
// 需要用到获得IP头部、ICMP头部的宏定义，已经写在实验代码的注释中了
void handle_ip_packet(iface_info_t *iface, char *packet, int len)
{
	//assert(0 && "TODO: function handle_ip_packet not implemented!");
	// 获取 IP 头部（以太网头部长度为 ETHER_HDR_SIZE）
    struct iphdr *ip = packet_to_ip_hdr(packet);

    // // 校验 IP 头部校验和，非法报文直接丢弃
    // if (ip_checksum(ip) != 0) {
    //     log(ERROR, "IP header checksum error");
    //     return;
    // }
// 获取 ICMP 头部（IP 头部长度由 ip->ihl 决定，单位是 4 字节）
    struct icmphdr *icmp = (struct icmphdr *)IP_DATA(ip);
    // 如果目标 IP 地址等于本机接口的 IP 地址，说明这个包是发给本机的
    if (icmp->type == ICMP_ECHOREQUEST && ntohl(ip->daddr) == iface->ip) {
        // 如果是 ICMP Echo Request（类型 8），就回复 ICMP Echo Reply（类型 0）
        // 回复 ICMP Echo Reply（只交换 src/dst 地址 + 修改 type 字段）
        log(DEBUG,"send to me");
        icmp_send_packet(packet, len, ICMP_ECHOREPLY, 0);
    }else{
        log(DEBUG,"转发数据包");
		ip_forward_packet(ntohl(ip->daddr),packet,len);
	}
}

// When forwarding the packet, you should check the TTL, update the checksum and TTL.
// Then, determine the next hop to forward the packet, then send the packet by iface_send_packet_by_arp.
// The interface to forward the packet is specified by longest_prefix_match.
void ip_forward_packet(u32 ip_dst, char *packet, int len)
{
	//assert(0 && "TODO: function ip_forward_packet not implemented!");
	struct iphdr *ip = packet_to_ip_hdr(packet);
    // 首先减少 TTL（生存时间），如果 <= 1，则发送 ICMP Time Exceeded
    ip->ttl--;
    if (ip->ttl <= 0) {
        icmp_send_packet(packet,len, ICMP_TIME_EXCEEDED, ICMP_EXC_TTL);
        free(packet);
        return;
    }

    // 更新 IP 校验和：因为 TTL 改了，必须重新计算
    ip->checksum = 0;
    ip->checksum = ip_checksum(ip);

    // 转发数据包：使用路由表查找下一跳
    rt_entry_t *entry = longest_prefix_match(ip_dst);
    if (!entry) {
        // 如果找不到路由，说明目标不可达，发送 ICMP Host Unreachable
        log(DEBUG,"can't find route");
        icmp_send_packet(packet, len, ICMP_DEST_UNREACH, ICMP_NET_UNREACH);
        free(packet);
        return;
    }else{
        ip_send_packet(packet,len);
        // u32 next_hop = (entry->gw == 0) ? ip_dst : entry->gw;

        // // Step 6: 发包（通过 ARP 获取 MAC 地址）
        // iface_send_packet_by_arp(entry->iface, next_hop, packet, len);

    }
}